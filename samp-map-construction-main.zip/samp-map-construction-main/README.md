# samp-map-construction
SA:MP Map Construction tool originally by [JernejL](https://github.com/JernejL/).

The source code can be found [here](https://github.com/JernejL/samp-map-editor). The tool is hosted here because there are no pre-built binaries for Windows available anywhere besides modding sites, that require waiting more time than's needed to download (5 / 10 / 15 second download link "generate" time), have a million ads or worse.. popups. 

--- 

This file is **unmaintained** so no support will be offered with running, adding to, or maintaining it yourself. It's merely offered "as-is". You run it at your own risk. "pawn-archive" / the team hold no responsibilty for any issues you run into. 

---

File Hashes: 

| **File Name**      	| **SHA256 Hash** 	|
|--------------------	|-----------------	|
| `editor.exe`       	| `577CC68ED91418989005AD8DB04EB9917A9F4AF4FDC1A9FE7E8E12A3E9406B6B`     	|
| `newton.dll`       	| `5A62625396ABCD729D37C969DE60B6FF72C36FE8BDA4F1AD96A5B97F2E96040B`     	|
| `GTAINTERFACE.dll` 	| `55E7974519205F1F2039FA5B3BCC9C64F5808F841BAA9101844605CD09333DF4`     	|


Virus Total: 
* [editor.exe](https://www.virustotal.com/gui/file/577cc68ed91418989005ad8db04eb9917a9f4af4fdc1a9fe7e8e12a3e9406b6b)
* [newton.dll](https://www.virustotal.com/gui/file/5a62625396abcd729d37c969de60b6ff72c36fe8bda4f1ad96a5b97f2e96040b)
* [GTAINTERFACE.dll](https://www.virustotal.com/gui/file/55e7974519205f1f2039fa5b3bcc9c64f5808f841baa9101844605cd09333df4)
